# ProyectoAPerizzolo
<h1>Proyecto Final del Curso de desarrollo Web<h1>
<p>Pagina web creada desde cero, utilizando lo aprendido en el curso de Desarrollo Web de Coder House<p>
<p>Creé la pagina de mi esposa, Licenciada en Terapia Ocupacional<p>
